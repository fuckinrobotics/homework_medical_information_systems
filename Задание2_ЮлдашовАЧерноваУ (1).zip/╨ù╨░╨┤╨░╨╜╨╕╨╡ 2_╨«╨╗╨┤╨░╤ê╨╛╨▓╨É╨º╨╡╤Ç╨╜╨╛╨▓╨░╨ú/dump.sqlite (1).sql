-- TABLE
CREATE TABLE BenefitMedicines (
  numberDiscount int NOT NULL,
  polisOms TEXT NOT NULL,
  typeBenefit TEXT NOT NULL,
  dateStartBenefit date NOT NULL,
  dateEndBenefit date NOT NULL,
  PRIMARY KEY (numberDiscount),
  FOREIGN KEY (polisOms) REFERENCES Client (polisOms),
  CONSTRAINT chk_date CHECK(dateEndBenefit >= dateStartBenefit)
);
CREATE TABLE "Client" ( "passport" TEXT NOT NULL, "polisOms" TEXT NOT NULL, "fullName" TEXT NOT NULL, PRIMARY KEY("passport"));
CREATE TABLE "Diseases" ( "diseaseNameD" TEXT NOT NULL, "descriptionDisease" TEXT NOT NULL, "durationDiseaseDay" TEXT NOT NULL, PRIMARY KEY("diseaseNameD"),
FOREIGN KEY("diseaseNameD") REFERENCES "SymptomsComplaintsToDisease"("diseaseName"));
CREATE TABLE "MedicinesControlRegistry" ( 
  numberRegistry  INT NOT NULL,
  numberMedication  INT NOT NULL, 
  nameMedication TEXT NOT NULL, 
  PRIMARY KEY("numberMedication")
  );
CREATE TABLE "MedicRecord" (
"numberRequest" INT NOT NULL,
"polisOms" TEXT, "nameDisease" TEXT NOT NULL, 
"dateStartDisease" Date NOT NULL, 
"dateEndDisease" Date NOT NULL, 
"medicinesNum" INT NOT NULL, 
"dateStartMedicines" DatE NOT NULL, 
"dateEndMedicines" Date NOT NULL, 
"receipt" TEXT NOT NULL, 
"nameDoctor" TEXT NOT NULL, 
PRIMARY KEY("numberRequest"),
FOREIGN KEY("medicinesNum") REFERENCES "MedicinesControlRegistry"("numberRegistry"),
FOREIGN KEY("polisOms") REFERENCES "Client"("polisOms"),
CHECK ("dateEndDisease" > "dateStartDisease"),CHECK ("dateEndMedicines" > "dateStartMedicines")
);
CREATE TABLE "SymptomsComplaintsToDisease" ( "diseaseName" TEXT NOT NULL, "SymptomsComplaints" TEXT NOT NULL, PRIMARY KEY("diseaseName"));
 
-- INDEX
 
-- TRIGGER
 
-- VIEW
 
